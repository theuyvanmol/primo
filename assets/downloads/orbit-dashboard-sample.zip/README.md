# ORBIT — Dashboard UI Starter — evaluation sample

This original PRIMO HTML/CSS starter is provided for internal evaluation and demonstration. It is not a production-ready, purchased template and does not confer a commercial resale licence. Product pricing in the marketplace is illustrative.

Files: index.html, design-tokens.json, README.md.

Open index.html or serve it with a static HTTP server. Edit the content and CSS in the HTML. Replace sample text and designed image placeholders with your own work. No third-party photography or client artwork is bundled. There is no payment, booking, authentication or form backend. Review accessibility, responsiveness and implementation before production use.

A commercial product licence, support policy and final deliverables need to be defined before selling the finished version.
